<!DOCTYPE html>
<html>
<head>
	<title>About Us | Employee Management System</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="https://fonts.googleapis.com/css?family=Lobster|Montserrat" rel="stylesheet">
</head>
<body>
	<header>
		<nav>
			<h1>Shruti Corp.</h1>
			<ul id="navli">
				<li><a class="homeblack" href="index.php">HOME</a></li>
				<li><a class="homered" href="aboutus.php">ABOUT US</a></li>
				<li><a class="homeblack" href="contact.php">CONTACT</a></li>
				<li><a class="homeblack" href="elogin.php">LOG IN</a></li>
			</ul>
		</nav>
	</header>
	<div class="divider"></div>

	

	</div>


</body>
</html>