<?php
require "config.php";

//$sql = "SELECT * from `employee_leave` order by employee_leave desc";
$sql ="Select add_emp.id, add_emp.full_name, employee_leave.start, employee_leave.end, employee_leave.reason, employee_leave.status, employee_leave.token From add_emp, employee_leave Where add_emp.id = employee_leave.id order by employee_leave.token";

//echo "$sql";
$result = mysqli_query($con, $sql);
$i=1;
	
?>

<html>
<head>
	<title>Employee Leave | Admin Panel | Employee Management System</title>
	<link rel="stylesheet" type="text/css" href="styleview.css">
</head>
<body>
	
	<header>
		<nav>
			<h1>EMS</h1>
			<ul id="navli">
				<li><a class="homeblack" href="aloginwel.php">HOME</a></li>
				
				<li><a class="homeblack" href="addemp.php">Add Employee</a></li>
				<li><a class="homeblack" href="viewemp.php">View Employee</a></li>
				<li><a class="homeblack" href="assign.php">Assign Project</a></li>
				<li><a class="homeblack" href="assignproject.php">Project Status</a></li>
				<li><a class="homeblack" href="salaryemp.php">Salary Table</a></li>
				<li><a class="homered" href="empleave.php">Employee Leave</a></li>
				<li><a class="homeblack" href="alogin.php">Log Out</a></li>
			</ul>
		</nav>
	</header>
	 
	<div class="divider"></div>
	<div id="divimg">
		<table>
			<tr>
				<th>Emp. ID</th>
				<th>Token</th>
				<th>Name</th>
				<th>Start Date</th>
				<th>End Date</th>
				<th>Total Days</th>
				<th>Reason</th>
				<th>Status</th>
				<th>Options</th>
			</tr>
			
				<?php
				
					$date1 = new DateTime($add_emp['start']);
					$date2 = new DateTime($add_emp['end']);
					$interval = $date1->diff($date2);
					$interval = $date1->diff($date2);
					?>
				
			</tr>
			<tr>
				<td><?php echo $i?></td>
				<td><?php echo $row['token']?></td>
				<td><?php echo $add_emp['full_name']?></td>
				<td><?php echo $add_emp['start']?></td>
				<td><?php echo $add_emp['end']?></td>
				<td><?php echo $interval->days?></td>
				<td><?php echo $add_emp['reason']?></td>
				<td><?php echo $add_emp['status']?></td>
				<td><a href=\"approve.php?id=$add_emp[id]&token=$add_emp[token]\"  onClick=\"return confirm('Are you sure you want to Approve the request?')\">Approve</a> | <a href=\"cancel.php?id=$add_emp[id]&token=$add_emp[token]\" onClick=\"return confirm('Are you sure you want to Canel the request?')\">Cancel</a></td>
				</tr>
				<?php 
				$i++;
				?>
				
			
			
			

		</table>
		
	</div>
</body>
</html>