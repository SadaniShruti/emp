
<html>
<head>
	<title>View Employee |  Admin Panel | Employee Management System</title>
	<link rel="stylesheet" type="text/css" href="styleview.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.2/css/bootstrap.min.css"/>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.2/js/bootstrap.bundle.min.js"></script>
</head>
<body>
	<header>
		<nav>
			<h1>EMS</h1>
			<ul id="navli">
				<li><a class="homeblack" href="aloginwel.php">HOME</a></li>
				<li><a class="homeblack" href="addemp.php">Add Employee</a></li>
				<li><a class="homered" href="viewemp.php">View Employee</a></li>
				<li><a class="homeblack" href="assign.php">Assign Project</a></li>
				<li><a class="homeblack" href="assignproject.php">Project Status</a></li>
				<li><a class="homeblack" href="salaryemp.php">Salary Table</a></li>
				<li><a class="homeblack" href="empleave.php">Employee Leave</a></li>
				<li><a class="homeblack" href="alogin.php">Log Out</a></li>
			</ul>
		</nav>
	</header>
	
	<div class="divider"></div>

		<table>
			<tr>

				<th align = "center">Emp. ID</th>
				<th align = "center">Picture</th>
				<th align = "center">Name</th>
				<th align = "center">Email</th>
				<th align = "center">Birthday</th>
				<th align = "center">Gender</th>
				<th align = "center">Contact</th>
				<th align = "center">Address</th>
				<th align = "center">Department</th>
				<th align = "center">Degree</th>
				<th align = "center">Points</th>
				<th align = "center">Options</th>
			</tr>
			
<?php
	require "config.php";
	
	$sql="SELECT * FROM `add_emp`,`rank` WHERE add_emp.id = rank.eid";
	$result=mysqli_query($con,$sql);
	$i=1;
	while($row=mysqli_fetch_assoc($result))
	{
?>
			
			<tr>
			<td><?php echo $i; ?>	
			<td><?php echo $pic = $row['pic'];?></td>
			<td><img src="<?php echo "http://localhost/emp/process/".$pic;?>" alt="img" height="60px" width = "60px">
			<td><?php echo $row['full_name']?>
			<td><?php echo $row['email']?>
			<td><?php echo $row['birthdate']?>
			<td><?php echo $row['gender']?>
			<td><?php echo $row['contact_no']?>
			<td><?php echo $row['address']?>
			<td><?php echo $row['department']?>
			<td><?php echo $row['degree']?>
			<td><?php echo $row['points']?>
			<td><a class="btn btn-danger" href="delete.php?id=<?php echo $row['id']; ?>">Delete</a></br></br>

			<button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop"
				data-bs-nm="<?php echo $row['full_name']; ?>"
				data-bs-mail="<?php echo $row['email'];?>"
				data-bs-brth="<?php echo $row['birthdate'];?>" 
				data-bs-gender="<?php echo $row['gender'];?>" 
				data-bs-cno="<?php echo $row['contact_no'];?>" 
				data-bs-add="<?php echo $row['address'];?>" 
				data-bs-dept="<?php echo $row['department'];?>" 
				data-bs-degree="<?php echo $row['degree'];?>" 
				data-bs-salary="<?php echo $row['salary'];?>" 
				data-bs-id="<?php echo $row['id']; ?>">Update</button>
	<?php
		$i++;
	}
	?>
	</table>
	</div>
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="staticBackdropLabel">Update Record</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
			<div class="modal-body">
				<form action="viewemp.php" method="POST">
				<div class="mb-3">
					<input type="text" name="txtfnm" class="form-control"  placeholder="full_name" id="fnm">
					<input type="text" name="txtid" class="form-control" id="id" hidden>
				</div>
				<div class="mb-3">
					<input type="text" name="em" class="form-control" placeholder="email" id="em">
				</div>
				<div class="mb-3">
					<input type="text" name="br" class="form-control" placeholder="birthdate" id="br">
				</div>
				<div class="mb-3">
					<input type="text" name="gen" class="form-control" placeholder="gender" id="gen">
				</div>
				<div class="mb-3">
					<input type="text" name="con" class="form-control" placeholder="contact" id="con">
				</div>
				<div class="mb-3">
					<input type="text" name="ad" class="form-control" placeholder="Address" id="ad">
				</div>
				<div class="mb-3">
					<input type="text" name="dp" class="form-control" placeholder="department" id="dp">
				</div>
				<div class="mb-3">
					<input type="text" name="dg" class="form-control" placeholder="degree" id="dg">
				</div>
				<div class="mb-3">
					<input type="text" name="slry" class="form-control" placeholder="salary" id="slry">
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-primary w-50">Update</button>
				</div>
				</form>
			</div>
		</div>
	</div>
</div>
</body>
</html>

<script>
	const exampleModal = document.getElementById('staticBackdrop')
	exampleModal.addEventListener('show.bs.modal', event => {
    const button = event.relatedTarget
    const nm = button.getAttribute('data-bs-nm')
    const mail = button.getAttribute('data-bs-mail')
    const brth = button.getAttribute('data-bs-brth')
    const gender = button.getAttribute('data-bs-gender')
    const cno = button.getAttribute('data-bs-cno')
    const add = button.getAttribute('data-bs-add')
    const dept = button.getAttribute('data-bs-dept')
	const degree = button.getAttribute('data-bs-degree')
	const salary = button.getAttribute('data-bs-salary')
    const id = button.getAttribute('data-bs-id')
    const modalTitle = exampleModal.querySelector('.modal-title')
	modalTitle.textContent = `Update Record ID ${id}`
    document.getElementById('fnm').value = nm;
    document.getElementById('em').value = mail;
    document.getElementById('br').value = brth;
    document.getElementById('gen').value = gender;
    document.getElementById('con').value = cno;
	document.getElementById('ad').value = add;
	document.getElementById('dp').value = dept;
	document.getElementById('dg').value = degree;
	document.getElementById('slry').value = salary;
	document.getElementById('id').value = id;
})

<?php
	if(isset($_POST['txtid']))
	{
		$id = $_POST['txtid'];
		$nm = $_POST['txtfnm'];
		$mail = $_POST['em'];
		$brth = $_POST['br'];
		$gender = $_POST['gen'];
		$cno = $_POST['con'];
		$add = $_POST['ad'];
		$dept= $_POST['dp'];
		$degree= $_POST['dg'];
		$salary= $_POST['slry'];
		$sql =  "UPDATE `add_emp` SET `full_name`='$nm',`email`='$mail',`birthdate`='$brth',`gender`='$gender',`contact_no`='$cno',`address`='$add',`department`='$dept',`degree`='$degree' WHERE id=$id";
		mysqli_query($con,$sql);
	}
?>		