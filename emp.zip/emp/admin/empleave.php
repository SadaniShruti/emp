<?php
require "config.php";

//$sql = "SELECT * from `employee_leave`";
$sql = "SELECT * FROM add_emp INNER JOIN employee_leave ON add_emp.id = employee_leave.id  order by employee_leave.token";

//echo "$sql";
$result = mysqli_query($con, $sql);

?>

<html>
<head>
	<title>Employee Leave | Admin Panel | Employee Management System</title>
	<link rel="stylesheet" type="text/css" href="styleview.css">
</head>
<body>
	
	<header>
		<nav>
			<h1>EMS</h1>
			<ul id="navli">
				<li><a class="homeblack" href="aloginwel.php">HOME</a></li>
				
				<li><a class="homeblack" href="addemp.php">Add Employee</a></li>
				<li><a class="homeblack" href="viewemp.php">View Employee</a></li>
				<li><a class="homeblack" href="assign.php">Assign Project</a></li>
				<li><a class="homeblack" href="assignproject.php">Project Status</a></li>
				<li><a class="homeblack" href="salaryemp.php">Salary Table</a></li>
				<li><a class="homered" href="empleave.php">Employee Leave</a></li>
				<li><a class="homeblack" href="alogin.php">Log Out</a></li>
			</ul>
		</nav>
	</header>
	 
	<div class="divider"></div>
	<div id="divimg">
		<table>
			<tr>
				<th>Emp. ID</th>
				<th>Token</th>
				<th>Name</th>
				<th>Start Date</th>
				<th>End Date</th>
				<th>Total Days</th>
				<th>Reason</th>
				<th>Status</th>
				<th>Options</th>
			</tr>
	
			
			<?php
				$sql = "SELECT * FROM add_emp INNER JOIN employee_leave ON add_emp.id = employee_leave.id";
				$result = mysqli_query($con, $sql);
				while($row=mysqli_fetch_assoc($result)){
				
					
					$date1 = new DateTime($add_emp['start']);
					$date2 = new DateTime($add_emp['end']);
					$interval = $date1->diff($date2);
					$interval = $date1->diff($date2);
					//echo "difference " . $interval->days . " days ";
				?>
		<tr>
			<td><?php echo $i; ?>	
			<td><?php echo $row['id']?>
			<td><?php echo $row['token']?>
			<td><?php echo $row['full_name']?>
			<td><?php echo $row['start']?>
			<td><?php echo $row['end']?>
			<td><?php echo $row['reason']?>
			<td><?php echo $row['status']?>
			<?php echo "<td><a href=\"approve.php?id=$add_emp[id]&token=$add_emp[token]\"  onClick=\"return confirm('Are you sure you want to Approve the request?')\">Approve</a> | <a href=\"cancel.php?id=$add_emp[id]&token=$add_emp[token]\" onClick=\"return confirm('Are you sure you want to Canel the request?')\">Cancel</a></td>";?>




			<?php
			$i++;
				}
			
				?>
			



		</table>
		
	</div>
</body>
</html>