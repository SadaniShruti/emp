
<html>
<head>
	<title>View Employee |  Admin Panel | Employee Management System</title>
	<link rel="stylesheet" type="text/css" href="styleview.css">
</head>
<body>
	<header>
		<nav>
			<h1>EMS</h1>
			<ul id="navli">
				<li><a class="homeblack" href="aloginwel.php">HOME</a></li>
				<li><a class="homeblack" href="addemp.php">Add Employee</a></li>
				<li><a class="homered" href="viewemp.php">View Employee</a></li>
				<li><a class="homeblack" href="assign.php">Assign Project</a></li>
				<li><a class="homeblack" href="assignproject.php">Project Status</a></li>
				<li><a class="homeblack" href="salaryemp.php">Salary Table</a></li>
				<li><a class="homeblack" href="empleave.php">Employee Leave</a></li>
				<li><a class="homeblack" href="alogin.php">Log Out</a></li>
			</ul>
		</nav>
	</header>
	
	<div class="divider"></div>

		<table>
			<tr>

				<th align = "center">Emp. ID</th>
				<th align = "center">Picture</th>
				<th align = "center">Name</th>
				<th align = "center">Email</th>
				<th align = "center">Birthday</th>
				<th align = "center">Gender</th>
				<th align = "center">Contact</th>
				<th align = "center">Address</th>
				<th align = "center">Department</th>
				<th align = "center">Degree</th>
				<th align = "center">Points</th>
				
				
				<th align = "center">Options</th>
			</tr>
			
<?php
	require "config.php";
	
	$sql="SELECT * FROM `add_emp`,`rank` WHERE add_emp.id = rank.eid";
	$result=mysqli_query($con,$sql);
	$i=1;
	while($row=mysqli_fetch_assoc($result))
	{
?>
			
			<tr>
			<td><?php echo $i; ?>	
			<td><img height="60" width="60" id="blah" src="process/<?php echo "imeges/".$row['pic'];?>">
			<td><?php echo $row['full_name']?>
			<td><?php echo $row['email']?>
			<td><?php echo $row['birthdate']?>
			<td><?php echo $row['gender']?>
			<td><?php echo $row['contact_no']?>
			<td><?php echo $row['address']?>
			<td><?php echo $row['department']?>
			<td><?php echo $row['degree']?>
			<td><?php echo $row['points']?>
			<td><a class="btn btn-danger" href="delete.php?id=<?php echo $row['id']; ?>">Delete</a>
			
	<?php
		$i++;
		}
	?>
	<script>
		imgInp.onchange = evt =>
			{
				const[file] = imgInp.files
				if(file)
				{
					blah.src=URL.createObjectURL(file)
				}
			}
	</script>
		</table>
		
	
</body>
</html>