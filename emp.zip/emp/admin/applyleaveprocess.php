<?php
require "config.php";
	//getting id of the data from url
$id = $_GET['id'];
//echo $id;
$reason = $_POST['reason'];

$start = $_POST['start'];
//echo "$reason";
$end = $_POST['end'];
function dateDiffInDays($date1, $date2)
{
	// Calculating the difference in timestamps
	$diff = strtotime($date2) - strtotime($date1);

	// 1 day = 24 hours
	// 24 * 60 * 60 = 86400 seconds
	return abs(round($diff / 86400));
}

// Start date
$date1 = "17-09-2018";

// End date
$date2 = "31-09-2018";

// Function call to find date difference
$dateDiff = dateDiffInDays($date1, $date2);

// Display the result
printf("Difference between two dates: "
	. $dateDiff . " Days ");
 $sql = "INSERT INTO `employee_leave`(`token`, `start`, `end`, `reason`, `status`) VALUES ('','$start','$end','$reason','Pending')";

$result = mysqli_query($con, $sql);
	
//redirecting to the display page (index.php in our case)
 header("Location:..//eloginwel.php?id=$id");
	
?>


