<?php

$servername = "localhost";
$dBUsername = "root";
$dbPassword = "";
$dBName = "shruti_mgt";

$con = mysqli_connect($servername, $dBUsername, $dbPassword, $dBName);

if(!$con){
	echo "Databese Connection Failed";
}

?>