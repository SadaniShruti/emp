<?php
	$con=mysqli_connect("localhost","root","","shruti_mgt");
?>