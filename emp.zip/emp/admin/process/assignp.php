<?php
require "config.php";

$pname = $_POST['pname'];
$eid = $_POST['eid'];
$subdate = $_POST['duedate'];

$sql = "INSERT INTO `project`(`eid`, `pname`, `duedate` , `status`) VALUES ('$eid' , '$pname' , '$subdate' , 'Due')";
$result = mysqli_query($con, $sql);
$empid = "";
if(mysqli_num_rows($result) == 1){
	
	$add_emp = mysqli_fetch_array($id);
	$empid = ($add_emp['id']);
	$full_name=($add_emp['ename']);

if(($result) == 1)
{
    header("Location: ..//assignproject.php");
}

else{
    echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Failed to Assign')
    window.location.href='javascript:history.go(-1)';
    </SCRIPT>");
}




?>