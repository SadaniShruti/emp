<?php
	$id = (isset($_GET['id']) ? $_GET['id'] : '');
	require "config.php";
	 $sql1 = "SELECT * FROM `add_emp` where id = '$id'";
	 $result1 = mysqli_query($con, $sql1);
	 $seq = 1;
	 $add_emp = mysqli_fetch_array($result1);
	 $empName = ($add_emp['full_name']);

	$sql = "SELECT * FROM add_emp INNER JOIN rank ON add_emp.id = rank.eid ";
	$sql1 = "SELECT `pname`, `duedate` FROM `project` WHERE eid = $id and status = 'Due'";

	$sql2 ="SELECT * FROM add_emp INNER JOIN employee_leave ON add_emp.id = employee_leave.id";

	$sql3 = "SELECT * FROM `salary` WHERE id = $id";
	$result = mysqli_query($con, $sql);
	$result1 = mysqli_query($con, $sql1);
	$result2 = mysqli_query($con, $sql2);
	$result3 = mysqli_query($con, $sql3);
	
   
	
	
//	echo "$sql";


?>


<html>
<head>
	<title>Employee Panel | Employee Management System</title>
	<link rel="stylesheet" type="text/css" href="styleemplogin.css">
	<link href="https://fonts.googleapis.com/css?family=Lobster|Montserrat" rel="stylesheet">
</head>
<body>
	
	<header>
		<nav>
			<h1>Employee Management System</h1>
			<ul id="navli">
				<li><a class="homered" href="eloginwel.php?id=<?php echo $id?>"">HOME</a></li>
				<li><a class="homeblack" href="myprofile.php?id=<?php echo $id?>"">My Profile</a></li>
				<li><a class="homeblack" href="empproject.php?id=<?php echo $id?>"">My Projects</a></li>
				<li><a class="homeblack" href="applyleave.php?id=<?php echo $id?>"">Apply Leave</a></li>
				<li><a class="homeblack" href="elogin.php">Log Out</a></li>
			</ul>
		</nav>
	</header>
	 
	<div class="divider"></div>
	<div id="divimg">
	<div>
		<!-- <h2>Welcome <?php echo "$empName"; ?> </h2> -->

		    	<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Empolyee Leaderboard </h2>
    	<table>

			<tr bgcolor="#000">
				<th align = "center">Seq.</th>
				<th align = "center">Emp. ID</th>
				<th align = "center">Name</th>
				<th align = "center">Points</th>
				

			</tr>
			<?php
				$seq = 1;
				while ($add_emp = mysqli_fetch_assoc($result)) {
					echo "<tr>";
					echo "<td>".$seq."</td>";
					echo "<td>".$add_emp['id']."</td>";
					
					echo "<td>".$add_emp['full_name']."</td>";
					
					echo "<td>".$add_emp['points']."</td>";
					
					$seq+=1;
				}


			?>



			
					
	

		</table>
   
    	<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Due Projects</h2>
    	

    	<table>

			<tr>
				<th align = "center">Project Name</th>
				<th align = "center">Due Date</th>
				
			</tr>

			

			<?php
				while ($add_emp1 = mysqli_fetch_assoc($result1)) {
					echo "<tr>";
					
					echo "<td>".$add_emp1['pname']."</td>";
					
					echo "<td>".$add_emp1['duedate']."</td>";

				}


			?>
				
			

		</table>



		<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Salary Status</h2>
    	

    	<table>

			<tr>
				
				<th align = "center">Base Salary</th>
				<th align = "center">Bonus</th>
				<th align = "center">Total Salary</th>
				
			</tr>

			

			<?php
				
					while ($row = mysqli_fetch_assoc($result3)) {
						?>
		<tr>
					
					
					<td><?php echo $row['base']?>
					<td><?php echo $row['bonus']?>
					<td><?php echo $row['total']?>
					<?php
						}
					?>

		</table>

		<h2 style="font-family: 'Montserrat', sans-serif; font-size: 25px; text-align: center;">Leave Satus</h2>
    	

    	<table>

			<tr>
				
				<th align = "center">Start Date</th>
				<th align = "center">End Date</th>
				<th align = "center">Total Days</th>
				<th align = "center">Reason</th>
				<th align = "center">Status</th>
			</tr>

			
					<?php
						while ($row = mysqli_fetch_assoc($result2)) {
					?>
	<tr>
		<td><?php echo $i?></td>
		<td><?php echo $row['id']?></td>
		<td><?php echo $row['token']?></td>
		<td><?php echo $row['full_name']?></td>
		<td><?php echo $row['start']?></td>
		<td><?php echo $row['end']?></td>
		<td><?php echo $row['reason']?></td>
		<td><?php echo $row['status']?></td>
	
			<td>
			<?php 
				if($row['status']==1){
					 echo "Applied";
				}if($row['status']==2){
					echo "Approved";
				}if($row['status']==3){
					echo "Rejected";
				}
				?>
				</td>
				<td><a href="empleave.php?id=<?php echo $row['id']?>&type=delete">Delete</a></td>
				</tr>
				<?php 
				$i++;
				}
				?>
	

		</table>
 
<br>
<br>
<br>
<br>
<br>

	</div>

		</h2>
		
	</div>
</body>
</html>