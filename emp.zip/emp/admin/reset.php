<?php 
require "config.php";
$sql1 = "UPDATE rank SET points = 0";
$sql2 = "UPDATE `salary` SET `total` = `base` ,`bonus` = 0";

mysqli_query($con , $sql1);
mysqli_query($con , $sql2);

header("Location:aloginwel.php");
 ?>