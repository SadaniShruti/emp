<?php
require "config.php";

$sql = "SELECT * from `employee_leave` order by employee_leave desc";
//$sql ="SELECT * FROM add_emp INNER JOIN employee_leave ON add_emp.id = employee_leave.id";

//echo "$sql";
$result2 = mysqli_query($con, $sql);
$i=1;
	while($row=mysqli_fetch_assoc($result2)){
?>

<html>
<head>
	<title>Employee Leave | Admin Panel | Employee Management System</title>
	<link rel="stylesheet" type="text/css" href="styleview.css">
</head>
<body>
	
	<header>
		<nav>
			<h1>EMS</h1>
			<ul id="navli">
				<li><a class="homeblack" href="aloginwel.php">HOME</a></li>
				
				<li><a class="homeblack" href="addemp.php">Add Employee</a></li>
				<li><a class="homeblack" href="viewemp.php">View Employee</a></li>
				<li><a class="homeblack" href="assign.php">Assign Project</a></li>
				<li><a class="homeblack" href="assignproject.php">Project Status</a></li>
				<li><a class="homeblack" href="salaryemp.php">Salary Table</a></li>
				<li><a class="homered" href="empleave.php">Employee Leave</a></li>
				<li><a class="homeblack" href="alogin.php">Log Out</a></li>
			</ul>
		</nav>
	</header>
	 
	<div class="divider"></div>
	<div id="divimg">
		<table>
			<tr>
				<th>Emp. ID</th>
				<th>Token</th>
				<th>Name</th>
				<th>Start Date</th>
				<th>End Date</th>
				<th>Total Days</th>
				<th>Reason</th>
				<th>Status</th>
				<th>Options</th>
			</tr>
			
			
			<tr>
				<td><?php echo $i?></td>
				<td><?php echo $row['id']?></td>
				<td><?php echo $row['token']?></td>
				<td><?php echo $row['full_name']?></td>
				<td><?php echo $row['start']?></td>
				<td><?php echo $row['end']?></td>
				<td><?php echo $row['reason']?></td>
				<td><?php echo $row['status']?></td>
		
			<td>
			<?php 
				if($row['status']==1){
					 echo "Applied";
				}if($row['status']==2){
					echo "Approved";
				}if($row['status']==3){
					echo "Rejected";
				}
				?>
			</td>
				<td><a href="empleave.php?id=<?php echo $row['id']?>&type=delete">Delete</a></td>
				</tr>
				<?php 
				$i++;
				}
				?>
	
			
			

		</table>
		
	</div>
</body>
</html>