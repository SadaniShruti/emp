<?php
require "config.php";

if(isset($_POST['submit'])){
	$reason=mysqli_real_escape_string($con,$_POST['reason']);
	$start=mysqli_real_escape_string($con,$_POST['start']);
	$end=mysqli_real_escape_string($con,$_POST['end']);
	$id=$_SESSION['id'];
	$status= mysqli_real_escape_string($con,$_POST['status']);
	$sql="INSERT INTO `employee_leave`(`id`,`start`, `end`, `reason`, `status`) VALUES ('','$start','$end','$reason','Pending')";
	$result = mysqli_query($con, $sql);
	header("Location:..//eloginwel.php?id=$id");
	die();
}
?>
	
	
	
	



